## ----syntax-vectors-1----------------------------------------------------
1:10
(1:10)^2
letters
length(month.name)

## ----syntax-vectors-2----------------------------------------------------
x <- 1:10 
x
sum(x)
class(x)

## ----syntax-combine------------------------------------------------------
x <- c(1, 1, 2, 3, 5, 8)
sum(x)
y <- c(x, 13, 21)
y

## ----syntax-character----------------------------------------------------
authors <- c("Ross", "Robert")
authors
length(authors)

## ----syntax-paste--------------------------------------------------------
lastnames <- c("Ihaka", "Gentleman")
paste(authors, c("Ihaka", "Gentleman"))
paste(authors, c("Ihaka", "Gentleman"), sep = "\t")
paste("row", 1:5, sep="_")

## ----syntax-paste0-------------------------------------------------------
paste("row", 1:5)
paste0("row", 1:5)

## ----syntax-logical------------------------------------------------------
authors == "Ross"
1:10 > 7
sum(1:10 > 7)

## ----syntax-subset-vectors-----------------------------------------------
letters[5]
letters[1:5]
letters[c(1, 3, 5)]

## ----syntax-subset-vectors-neg-int---------------------------------------
letters[-1]
letters[-(1:5)]
letters[-c(1,5,10,22,26,3)]


## ----syntax-subset-vectors-convenience-----------------------------------
head(letters)
head(letters, 1)
tail(letters)
tail(letters, 1)

## ----syntax-named-vectors------------------------------------------------
x <- 1:5
names(x) <- letters[1:5]
x

## ----subset-named--------------------------------------------------------
x["c"]
x[c("c", "d")]

names(x) <- rep("a", 5)
x["a"]
x[names(x) == "a"] 
x[]
x[26]
x[NA]
x[NULL]
x[0]
## ----syntax-factor-------------------------------------------------------
mtcars$cyl
as.factor(mtcars$cyl)

## ----matrix-1------------------------------------------------------------
matrix(1:9, nrow=3, ncol=3)
matrix(1:25, nrow=5, ncol=5, byrow =TRUE)
t(matrix(1:9, nrow=3, ncol=3))

## ----matrix-2------------------------------------------------------------
mat <- matrix(1:25, nrow=5)
mat

mat <- matrix(1:25, nrow=5, ncol = 10)
mat <- matrix(1:23, nrow=5, byrow =TRUE)
ceiling(length(1:23) / 5)
mat <- matrix(c(1:23,NA,NA), nrow=5)
mat <- matrix(nrow = 5, ncol = 5)

## ----syntax-subset-matrix-2----------------------------------------------
mat[2:4, 3:5]

## ----syntax-subset-matrix------------------------------------------------
mat[-3, -4]

## ----syntax-subset-matrix-empty------------------------------------------
mat[-3, ]
mat[5, 1] <- NA

mat %*% mat

## ----syntax-array--------------------------------------------------------

array.one <- array( 1:12, dim = c(3,4))
array.two <- array( 1:24, dim = c(3,4,2))

## ----syntax-array-subset-------------------------------------------------
array.two[,,1]
array.two[1,,]


## ----syntax-names--------------------------------------------------------
colnames(mat) <- paste("col", 1:5, sep="")
rownames(mat) <- paste0("row", 1:5)
mat 

## ----syntax-subset-names-------------------------------------------------
mat[c("row2","row3"),c("col1","col5")]

myMat <- matrix(myVec, nrow = 5, ncol =10)

## ----syntax-list---------------------------------------------------------
xl <- list(
  myNum = 1:10, 
  NewString = letters[1:15], 
  ABCDEF = rep(c(TRUE,FALSE), 10)
)
xl

yl <- list(
  num2 = 101:200,
  mylist = xl,
  myMat = myMat,
  FUN = mean
  )

class(yl) <- "lm"

## ----syntax-subset-list-single-------------------------------------------
out.single <- xl[1]
length(out.single)
class(out.single)

## ----syntax-subset-list-double-------------------------------------------
out.double <- xl[[1]]
length(out.double)
class(out.double)

xl[[1]]

xl2 <- list(1:3, 100:30, letters)
xl2[[1]]
variableName <- "NewString"
## xl$variableName ## this won't work
xl["NewString"]
xl[variableName]
xl[1]
xl[-1]
xl[c(TRUE,FALSE,TRUE)]

xl[[2]]
xl[[variableName]]
xl[["NewString"]]
xl$NewString

length(xl[2])
class(xl[2])
xl[2:3]
length(xl[[2]])
class(xl[[2]])
xl[[2:4]]

## ----syntax-data-frame-head-cars-----------------------------------------
head(mtcars)

## ----syntax-data-frame-str-cars------------------------------------------
str(mtcars)

## ----syntax-data-frame-rownames------------------------------------------
names(mtcars)
colnames(mtcars)
rownames(mtcars)

## ----syntax-df-2---------------------------------------------------------
dat <- data.frame(
  char = letters[1:5],
  num  = 1:5,
  log  =  c(TRUE,FALSE,TRUE,FALSE,TRUE)
  )

head(dat)

## ----syntax-df-----------------------------------------------------------
class(mtcars)
typeof(mtcars)

## ----syntax-subset-dollar------------------------------------------------
cars$speed[1]

## ----syntax-head-data.frame----------------------------------------------
head(cars)

## ----syntax-dim----------------------------------------------------------
nrow(mtcars)
ncol(mtcars)
dim(mtcars)

## ----syntax-class, eval=FALSE--------------------------------------------
#  help(class)

