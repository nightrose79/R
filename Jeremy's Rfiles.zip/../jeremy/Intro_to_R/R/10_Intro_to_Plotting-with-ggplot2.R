## ----plot-ggplot-spec, eval=FALSE, tidy=FALSE----------------------------
#  ggplot(data, mapping) +
#    layer(
#      stat = "",
#      geom = "",
#      position = "",
#      geom_parms = list(),
#      stat_params = list(),
#    )

## ----plot-qplot-mtcars-bar-----------------------------------------------
library("ggplot2")
theme_set(theme_bw())
qplot(mpg, data = mtcars)
qplot(mpg, data = mtcars, binwidth = 6)

## ----plot-qplot-mtcars-scatter-------------------------------------------
qplot(x = hp, y = mpg, data = mtcars)

## ----plot-qplot-mtcars-color---------------------------------------------
qplot(x = hp, y = mpg, data = mtcars, colour = cyl, size = mpg)

## ----plot-qplot-mtcars-size----------------------------------------------
qplot(x = hp, y = mpg, data = mtcars, color = factor(vs), 
      size = disp, shape = factor(am),
      facets = . ~ gear)

## ----plot-qplot-mtcars-facet---------------------------------------------
qplot(x = hp, y = mpg, data = mtcars, color = cyl, facets = .~ gear, 
      label = rownames(mtcars), geom=c("text","point"), 
      size = .1,  hjust=-0.25)

qplot(x = hp, y = mpg, data = mtcars, color = cyl,  
      geom=c("point", "smooth"), method = "lm")

qplot(x = hp, y = mpg, data = mtcars, color = cyl,  
      geom=c("point", "smooth"), method = "lm", formula = y ~ poly(x, 2))

ggplot(mtcars, aes(x = hp, y = mpg, color = cyl)) + 
  geom_point() + geom_smooth(method = "lm", formula = y ~ poly(x, 2))

## ----plot-ggplot-basic---------------------------------------------------
p <- ggplot(data = mtcars, aes(hp, mpg, label = rownames(mtcars))) +
  geom_point(aes(colour = cyl)) 
p

## ----plot-ggplot-print---------------------------------------------------
print(p)

## ----plot-ggplot-labels--------------------------------------------------
p2 <- p + facet_grid(.~gear) +
  geom_text(aes(colour = cyl), size = 3,  hjust=-0.25) +
  ggtitle("ggplot2 example")
print(p2)
print(p)

ggplot(mtcars, 
       aes(x = hp, y = mpg, color = factor(vs), 
           size = disp, shape = factor(am))) + 
  geom_point() + facet_grid(. ~ gear)

qplot(x = hp, y = mpg, data = mtcars, color = factor(vs), 
      size = disp, shape = factor(am),
      facets = . ~ gear)

## ----plot-ggplot-finance-download, eval=FALSE----------------------------
#  msft.url <- "http://www.google.com/finance/historical?q=NASDAQ:MSFT&output=csv"
#  goog.url <- "http://www.google.com/finance/historical?q=NASDAQ:GOOG&output=csv"
#  aapl.url <- "http://www.google.com/finance/historical?q=NASDAQ:AAPL&output=csv"
#  
#  msft.data <- read.table(msft.url, header = TRUE, sep = ",")
#  msft.data$name<- "MSFT"
#  goog.data <- read.table(goog.url, header = TRUE, sep = ",")
#  goog.data$name<- "GOOG"
#  aapl.data <- read.table(aapl.url, header = TRUE, sep = ",")
#  aapl.data$name<- "AAPL"
#  stock.data <- rbind(msft.data, goog.data, aapl.data)

## ----plot-ggplot-finance-local-import------------------------------------
stock.data <- read.csv("../data/stock_data.csv")
head(stock.data)

## ----plot-ggplot-finance-date--------------------------------------------
# stock.data$Date <- as.Date(stock.data$Date , "%d-%b-%y")
stock.data$Date <- as.Date(stock.data$Date)

## ----plot-ggplot-geom-line-----------------------------------------------
ggplot(stock.data, aes(x=Date, y=Close, group=name)) +
  geom_line(aes(color = name)) 

## ----plot-ggplot-geom-corr-src, echo = TRUE, eval = FALSE----------------
#  bacf = acf(x=stock.data$Date, plot=F)
#  bacfdf <- with(bacf, data.frame(lag, acf))
#  ggplot(data=bacfdf, mapping=aes(x=lag, y=acf)) +
#         geom_bar(stat = "identity", position = "identity", width=.1)

## ----plot-ggplot-geom-corr, ref.label = "plot-ggplot-geom-corr-src", echo = FALSE, eval = TRUE----
bacf = acf(x=stock.data$Date, plot=F)
bacfdf <- with(bacf, data.frame(lag, acf))
ggplot(data=bacfdf, mapping=aes(x=lag, y=acf)) +
       geom_bar(stat = "identity", position = "identity", width=.1)

## ----plot-ggplot-finance-normalize---------------------------------------
stock.data.norm <- stock.data[, c('Date', 'Close', 'Volume', 'name')]
stock.data.norm <- do.call('rbind',
  by(stock.data.norm,stock.data$name,function(STOCK){
  	STOCK$Close <- STOCK$Close/STOCK$Close[nrow(STOCK)]
		return(STOCK)
	})
)

## ----plot-ggplot-finance-normalize-plot----------------------------------
ggplot(stock.data.norm, aes(x=Date, y=Close, group=name)) +
  geom_line(aes(color = name)) 

## ----plot-ggplot-finance-volume------------------------------------------
stock.data.norm$Volume <- stock.data.norm$Volume / max(stock.data.norm$Volume)
ggplot(stock.data.norm, aes(x=Date, y=Close, group=name)) +
  geom_line(aes(color = name, size=Volume)) 

qplot(x = Close, data = stock.data.norm)
qplot(x = Close, data = stock.data.norm, color = name, fill = name)
ggplot(stock.data.norm, aes(x = Close, fill = name)) + geom_histogram()
ggplot(stock.data.norm, aes(x = Close, fill = name)) + geom_histogram(binwidth = 0.05)
ggplot(stock.data.norm, aes(x = Close, fill = name)) + 
  geom_histogram(binwidth = 0.05, position = "dodge") ## not effective
ggplot(stock.data.norm, aes(x = Close, fill = name)) + 
  geom_histogram(binwidth = 0.05)  + facet_grid(name ~ . )
ggplot(stock.data.norm, aes(x = Close, colour = name)) + geom_freqpoly(size = 3)
ggplot(stock.data.norm, aes(x = Close, colour = name)) + geom_density(size = 3)
ggplot(stock.data.norm, aes(x = Close, y = 1)) + geom_bin2d() + facet_grid(name ~ . )

ggplot(stock.data, aes(x=Date, y=Close, 
                       ymin=5*(Low - Close) + Close, 
                       ymax=5*(High-Close) + Close, group=name)) +
  geom_ribbon(aes(fill = name), alpha = 0.4) + geom_line(aes(color = name)) 

ggplot(stock.data, aes(x=Date, y=Close, 
                       ymin=5*(Low - Close) + Close, 
                       ymax=5*(High-Close) + Close, group=name)) +
  geom_ribbon() + geom_line(aes(color = name)) 

ggplot(stock.data, aes(x=Date, y=Close, ymin=5*(Low - Close) + Close, ymax=5*(High-Close) + Close, group=name)) +
  geom_ribbon(aes(fill = name), alpha = 0.4) + geom_line(aes(color = name)) + 
  scale_color_manual(values = c("orange","purple","black")) +
  scale_fill_manual(values = c("orange","purple","black"))

reorg_stats <- read.csv("../data/reorg_stats.csv")
ggplot(reorg_stats, aes(x = Auto, y = Health)) + geom_bin2d()
ggplot(reorg_stats, aes(x = Auto, y = Health)) + geom_density2d()


