## ------------------------------------------------------------------------
test <- function(a,b) return(a + b)
test
test(1,2)

## ----, eval=FALSE--------------------------------------------------------
function.name <- function(arguments){
}

## ------------------------------------------------------------------------
test <- function(a=1, b=2) return(a + b)
test()
test(a=3,b=5)

myMinMax <- function(x){
  c(min(x), max(x))
}
myIQR <- function(x){
  quantile(x, c(0.25,0.75))
}
## ------------------------------------------------------------------------

my.var <- 1
temp.func <- function() my.var <- 5
temp.func()
my.var

## ------------------------------------------------------------------------
my.var <- 1
temp.func2 <- function() print(5 + my.var)
temp.func2()

## ------------------------------------------------------------------------
a <- 0
env.function <- function(){
  a <<- 1
}
env.function()
a

myOutFun <- function(){
  x <- 1:3
  myInnerFun2 <- function(){
    x + 3
  }
  y <- myInnerFun2()
  return(y)
}

myInnerFun <- function(){
  x + 3
}

myQuad <- function(a,b,c){
  underTheRoot <- b^2 - 4*a*c
  if(underTheRoot < 0) {return(NA)}
  plusPiece <- (-b + sqrt(underTheRoot))/(2*a)
  minusPiece <- (-b - sqrt(underTheRoot))/(2*a)
  return(c(plusPiece, minusPiece))
}


myQuad2 <- function(a,b,c){
  underTheRoot <- b^2 - 4*a*c
  if(underTheRoot < 0) {underTheRoot <- as.complex(underTheRoot)}
  plusPiece <- (-b + sqrt(underTheRoot))/(2*a)
  minusPiece <- (-b - sqrt(underTheRoot))/(2*a)
  return(c(plusPiece, minusPiece))
}

myQuad2 <- function(a,b,c){
  underTheRoot <- b^2 - 4*a*c
  if(underTheRoot < 0) {underTheRoot <- as.complex(underTheRoot)}
  out <- (-b + c(1,-1)*sqrt(underTheRoot))/(2*a)
  return(out)
}