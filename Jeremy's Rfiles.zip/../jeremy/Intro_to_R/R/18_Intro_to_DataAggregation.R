## ----manip-table---------------------------------------------------------
table(mtcars[, "gear"])

## ----manip-table-2, size='tiny'------------------------------------------
table(mtcars[,c("gear","cyl")])
table(mtcars[,c("cyl","gear")])

table(mtcars[,c("cyl","gear","am")])

table(mtcars$cyl,mtcars$gear)
## ----manip-xtabs-1-------------------------------------------------------
xtabs(~gear + cyl, data = mtcars)

out <- xtabs(~am + carb, data = mtcars)
out[1,2]
out["1","2"]
xtabs(~am + carb, data = mtcars[mtcars$hp < 100,])
table(mtcars$am,mtcars$carb,mtcars$hp < 100)

xtabs(hp ~ am + carb, data = mtcars)

stock.data <- read.csv('../data/stock_data.csv')
xtabs(as.numeric(Volume) ~ name, data =stock.data)
xtabs( ~ name, data =stock.data)

## ----formula-1, eval=FALSE-----------------------------------------------
#  ## Not evaluated again
#  xtabs(~gear + cyl, data=mtcars)

## ----manip-xtabs-2, eval=FALSE-------------------------------------------
#  xtabs(~gear, mtcars)
#  xtabs(~gear + carb, mtcars)
#  xtabs(~gear + cyl + carb, mtcars)

## ----manip-aggregate-1---------------------------------------------------
aggregate(hp ~ cyl + gear, data=mtcars, FUN=mean) 

## ----manip-aggregate-2, eval=1, size='tiny'------------------------------
aggregate(hp ~ cyl + gear, data=mtcars, FUN=median) 
aggregate(hp ~ cyl + gear, data=mtcars, FUN=min) 
aggregate(hp ~ cyl + gear, data=mtcars, FUN=max)
aggregate(hp ~ cyl + gear, data=mtcars, FUN=length)

## ----manip-aggregate-3, size='tiny'--------------------------------------
aggregate(hp ~ cyl + gear, data=mtcars, 
          FUN=quantile, probs=c(0.25,0.75)) 

## ----manip-aggregate-4, size='tiny'--------------------------------------
aggregate(cbind(hp,mpg) ~ cyl + gear, data=mtcars, FUN=mean) 

aggregate(cbind(hp,mpg) ~ cyl + gear, data=mtcars, FUN=summary) 

## ----apply-family-tapply-------------------------------------------------
# Similar to Pivot Tables (PT) in Excel
# tapply(X, INDEX, FUN = NULL, ..., simplify = TRUE)
# ... where X are the PT Values, INDEX are the PT Row and Column Labels and FUN is the what we choose to summarize the Value field by in the PT
aggregate(mpg ~ carb + gear, data=mtcars, FUN=mean) 

tapply(mtcars$mpg,mtcars[,c('gear','carb')],mean, na.rm=TRUE)

as.data.frame.table(tapply(mtcars$mpg,mtcars[,c('gear','carb')],mean), responseName = "meanmpg")

## ----apply-family-tapply-agg-comp,tiny=FALSE-----------------------------
aggregate(mpg ~ gear + carb, data=mtcars, FUN=mean)

xtabs( ~ am + carb + gear, data=mtcars) 
xtabs( hp ~ am + carb + gear, data=mtcars) 
aggregate( hp ~ am + carb + gear, data=mtcars, FUN = sum) ## format will be different
tapply(mtcars$mpg,mtcars[,c("am",'carb','gear')],length)
tapply(mtcars$hp,mtcars[,c("am",'carb','gear')],sum)
tapply(mtcars$mpg,mtcars[,c('am','cyl')],sum)

out <- tapply(mtcars$mpg,mtcars[,c('am','cyl')], FUN = function(x){c(min(x), max(x))})
class(out)
class(out[1,1])



