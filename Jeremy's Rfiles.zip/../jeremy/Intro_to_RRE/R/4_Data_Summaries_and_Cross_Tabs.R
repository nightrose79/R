## ----dirsetup------------------------------------------------------------
data.path <- "../data"
output.path <- "../output/xdf"
if (is.na(file.info(output.path)$isdir)) dir.create(output.path, recursive = TRUE)
infile <- file.path(data.path, "BankXDF.xdf") 
BankDS <- RxXdfData(file = infile) 

## ----rxGetInfoHelper1----------------------------------------------------
(bankInfo <- rxGetInfo(BankDS))

## ----getVarInfo, output.max = 15-----------------------------------------
rxGetVarInfo(BankDS)

## ----rxGetVarNames-------------------------------------------------------
rxGetVarNames(BankDS)

## ----churnSetup----------------------------------------------------------
churnfile <- file.path(data.path,"ChurnData.xdf")
ChurnDS <- RxXdfData(file = churnfile)

## ----rxSummaryArgs-------------------------------------------------------
args(rxSummary)

## ----rxSummaryExampleForm, eval=FALSE------------------------------------
rxSummary(~ default + balance, data = BankDS)

## ----bankSummary1, output.max = 15---------------------------------------
BankSummary <- rxSummary(~ balance + age, data = BankDS) 
BankSummary$sData

## ----rxSummaryExampleForm2, eval=FALSE-----------------------------------
rxSummary(  ~ balance , data = BankDS)

## ----bankSummary2, output.max = 8----------------------------------------
BankSummary2 <- rxSummary( balance ~ F(age), data = BankDS) 
BankSummary2$categorical[[1]]      

## ----rxQuantileArgs------------------------------------------------------
args(rxQuantile)

## ----Quantiles-setup-----------------------------------------------------
infile <- file.path(data.path, "BankSubXDF.xdf") 
BankSubDS <- file.path(output.path, "BankSubXDF.xdf") 
origBankSubDS <- RxXdfData(file = infile) 

rxQuantile("age", origBankSubDS)

## ----rxCrossTabsArgs-----------------------------------------------------
args(rxCrossTabs)

## ----rxCubeArgs----------------------------------------------------------
args(rxCube)

## ----CrossTabsExample, output.max = 15-----------------------------------
rxCrossTabs(~default:marital, data = BankDS)
rxCrossTabs(~job:marital:default, data = BankDS)

rxCube(~job:marital + default, data = BankDS)

rxCrossTabs(balance~marital, data = BankDS, means = TRUE)
rxCrossTabs(balance~F(age, low=20, high=30):F(campaign, low=1, high=5), data = BankDS)


rxCrossTabs( ~ F(n.family.members):F(n.devices), data = ChurnDS)
rxCube( ~ F(n.family.members):F(n.devices), data = ChurnDS)

## ----rxLinePlotArgs------------------------------------------------------
args(rxLinePlot)

## ----rxLinePlotExample---------------------------------------------------
rxLinePlot(balance ~ age, type = "p", data = origBankSubDS)

## ----rxHistArgs----------------------------------------------------------
args(rxHistogram)

## ----ExamplerxHist-------------------------------------------------------
outFile  <- file.path(output.path, "tmp.xdf")
rxDataStep(origBankSubDS, outFile, 
           transforms = list(ageGroup = cut(age, breaks = c(0,29.5,43.5,61.5,95.5))),
           overwrite = TRUE)

rxHistogram(~balance | ageGroup, data = outFile) 

