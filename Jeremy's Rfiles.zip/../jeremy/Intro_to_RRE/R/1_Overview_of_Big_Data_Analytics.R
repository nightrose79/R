## ----printBankData, echo=FALSE-------------------------------------------
data.path  <-  "../data"
infile <- file.path(data.path,"bank-full.csv")
BankDS <- RxTextData(file = infile) 
bank.info <- rxGetInfo(BankDS, numRows=6)
subset(bank.info[["data"]], select = age:loan)

## ----printBankData2, echo=FALSE------------------------------------------
subset(bank.info[["data"]], select = contact:y)

## ----printChurnData, echo=FALSE, output.max = 13-------------------------
churnfile <- file.path(data.path,"ChurnData.xdf")
ChurnDS <- RxXdfData(file = churnfile) 
churn.info <- rxGetInfo(ChurnDS, getVarInfo = TRUE)
churn.info

