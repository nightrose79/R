## ----argsrxDataStep------------------------------------------------------
args(rxDataStep)

## ----dirsetup------------------------------------------------------------
## set up general directories
data.path <- "../data"
output.path <- "../output/xdf"
if (is.na(file.info(output.path)$isdir)) dir.create(output.path, recursive = TRUE)
## set up bank paths
infile <- file.path(data.path, "BankXDF.xdf") 
origBankDS <- RxXdfData(file = infile)
outfile <- file.path(output.path, "myBankXDF.xdf") 
## set up churn paths:
inChurnfile <- file.path(data.path, "ChurnData.xdf")
ChurnDS <- RxXdfData(inChurnfile)
outChurnfile <- file.path(output.path, "myChurnData.xdf")

## ----rxDataStepExample---------------------------------------------------
BankDS <- rxDataStep(inData = origBankDS, outFile = outfile, 
                    varsToKeep = c("balance", "age", "y", "poutcome"), 
                    overwrite = TRUE)
BankDS

myChurnDS <- rxDataStep(inData = ChurnDS, outFile = outChurnfile, 
                     varsToKeep = c("n.family.members", "n.devices"), 
                     overwrite = TRUE)
myChurnDS

# ID, Region, State, ..., Val001,Val002,Val003,...Val999
curNames <- rxGetVarNames(BankDS)
# myCols2Use <- grep("Val", curNames, value = TRUE)
# use myCols2Use as varsToKeep

## ----getVarInfoBankDS----------------------------------------------------
rxGetVarInfo(BankDS)

## ----rowSelection--------------------------------------------------------
outfile.rs <- file.path(output.path, "BankRS.xdf")
BankDS.rs <- rxDataStep(inData = origBankDS, outFile = outfile.rs, 
                        rowSelection = (age > 21 & balance > 2000) | y == "yes",
                        overwrite = TRUE)
BankDS.rs

## ----rowSelection2-------------------------------------------------------
outfile.rs <- file.path(output.path, "BankRS.xdf")
BankDS.rs <- rxDataStep(inData = origBankDS, outFile = outfile.rs, 
                        varsToKeep = c("balance", "y", "poutcome"),
                        rowSelection = age < 21,
                        overwrite = TRUE)
BankDS.rs

newFile <- file.path(output.path,"ChurnSubXDF2.xdf")
myChurnDS <- rxDataStep(inData = ChurnDS, outFile = newFile, 
                        rowSelection = n.devices > 3,
                        varsToKeep = c("n.family.members", "n.devices"), 
                        overwrite = TRUE)
rxGetInfo(myChurnDS, getVarInfo = TRUE)

## ----exampleTransforms---------------------------------------------------
myTrans <- list( newBalance = balance + 8019 + 1,
      newBalance2 = balance + 10000,
      age2 = age^2)

rxDataStep(inData = BankDS, outFile = BankDS,
           transforms = list( newBalance3 = balance + 8019 + 1,
                              newBalance4 = newBalance33 + 120,
                              age2 = age^2),
           overwrite=TRUE)
rxGetInfo(BankDS, varsToKeep = c("balance", "newBalance"), getVarInfo = TRUE)

## ----LinePlotBalanceAge--------------------------------------------------
rxLinePlot(balance ~ age, type = "p", data = BankDS)

## ----lineplotnewbalanceage-----------------------------------------------
rxLinePlot(newBalance ~ age, type = "p", data = BankDS,           
           panel = function(x,y,...){
             panel.xyplot(x,y,...)
             panel.lmline(x,y,...)
           }
           )
rxHistogram( ~ age, data = BankDS,
             )


rxDataStep(inData = myChurnDS, outFile = myChurnDS,
           transforms = list( n.device.per.person = n.devices / n.family.members ),
           overwrite=TRUE)

idf <- rxDataStep(myChurnDS, 
                  rowSelection = n.family.members == 0 )

## ----setVarInfoArgs------------------------------------------------------
args(rxSetVarInfo)

## ----setupRecode, tidy=FALSE---------------------------------------------
newVarInfo <- list(
  y = list(
    newName = "term.deposit", 
    description = "Customer has subscribed to a term deposit"
  ), 
  poutcome = list(
    newName = "campaign.outcome", 
    description = "Outcome of prior marketing campaign"
  )
  ) 

## ----setVarInfo----------------------------------------------------------
rxSetVarInfo(varInfo = newVarInfo, data = BankDS) 
rxGetVarInfo( BankDS ) 

## ----rxSortArgs----------------------------------------------------------
args(rxSort)

## ----rxSortExample-------------------------------------------------------
rxSort(inData = BankDS, outFile = BankDS, 
       sortByVars=c('balance', 'age'),
       decreasing = c(FALSE, TRUE),
       overwrite=TRUE)

## ----rxGetInfoSorted-----------------------------------------------------
rxGetInfo(BankDS, numRows=5)

outSort <- file.path(output.path,"churn.sort.xdf")
rxSort(inData = ChurnDS, outFile = outSort, 
       sortByVars=c('n.devices', 'n.family.members'),
       decreasing = c(TRUE, FALSE),
       overwrite=TRUE)
outSort2 <- file.path(output.path,"churn.sort.rmdup.xdf")
rxSort(inData = ChurnDS, outFile = outSort, 
       sortByVars=c('n.devices', 'n.family.members'),
       removeDupKeys = TRUE,
       decreasing = c(TRUE, FALSE),
       overwrite=TRUE)
rxGetInfo(outSort, numRow = 15)

## ----removeDuplicates----------------------------------------------------
outfile2 <- file.path(output.path, "BankXDF_sort2.xdf") 
BankDS2 <- rxSort(inData = BankDS, outFile = outfile2,
                    sortByVars=c('balance', 'age'), decreasing = c(FALSE, TRUE), 
                    removeDupKeys=TRUE, dupFreqVar="Dup_Count", 
                    overwrite = TRUE)

## ----seeDeDuplicate------------------------------------------------------
rxGetInfo(BankDS, numRows=5)
rxGetInfo(BankDS2, numRows=5)

## ----linModExample, eval = FALSE-----------------------------------------
#  linMod <- rxLinMod(balance~age, data=BankDS2, fweights="Dup_Count")

