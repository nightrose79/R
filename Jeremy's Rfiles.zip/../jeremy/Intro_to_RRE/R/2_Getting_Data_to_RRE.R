## ----dirsetup------------------------------------------------------------
data.path <- "../data"
output.path  <- "../output/xdf"
if (is.na(file.info(output.path)$isdir)) dir.create(output.path, recursive = TRUE)
(infile <- file.path(data.path, "bank-full.csv"))
(outfile <- file.path(output.path, "BankXDF.xdf"))
(outfile2 <- file.path(output.path, "Bank"))

## ----rxImportArgs--------------------------------------------------------
args(rxImport)

## ----rxImport------------------------------------------------------------
colClasses <- c("integer", rep("factor",4), "integer", 
                rep("factor",3), "integer", "factor", rep("integer",4), rep("factor",2))
names(colClasses) <- c("age", "job", "marital", "education", "default", "balance", 
"housing", "loan", "contact", "day", "month", "duration", "campaign", 
"pdays", "previous", "poutcome", "y")

BankXDF <- rxImport(inData = infile, outFile = outfile,
                    colClasses=colClasses, rowsPerRead=10000,
                    overwrite = TRUE)
rxGetInfo(outfile) ## will work
summary(outfile) ## won't
summary(BankXDF) ## will work
head(BankXDF)
rxGetInfo(BankXDF, numRows = 6)
mydf <- rxReadXdf(BankXDF, numRows = 6)
mydf2 <- rxReadXdf(BankXDF, startRow = 7, numRows = 6)

## ----churninfo-----------------------------------------------------------
ChurnXDF <- file.path(data.path, "ChurnData.xdf")
summary(ChurnXDF)
ChurnXDF <- RxXdfData(ChurnXDF)
summary(ChurnXDF)

## ----rxGetInfoArgs-------------------------------------------------------
args(rxGetInfo)

## ----rxGetInfoBank, output.max = 13--------------------------------------
rxGetInfo(BankXDF)
rxGetInfo(BankXDF, getVarInfo = TRUE)

bankVarInfo <- rxGetVarInfo(BankXDF)
bankTypes <- vapply(bankVarInfo,"[[","varType", FUN.VALUE=character(1))
lapply(bankVarInfo[bankTypes == "integer"], "[[", "high")

## ----dataSource----------------------------------------------------------
infile <- file.path(data.path, "bank-full.csv") 
BankDS <- RxTextData(file = infile) 
rxGetInfo(BankDS, numRows=6)

