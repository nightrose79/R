## ----covexample----------------------------------------------------------
icecream.df <- read.csv("http://vincentarelbundock.github.io/Rdatasets/csv/Ecdat/Icecream.csv", header=TRUE)
with(icecream.df, cov(cons, temp))

## ----covmatexample-------------------------------------------------------
cov(icecream.df[-1])

## ----rxCorExample1-------------------------------------------------------
data.path = "../data"
infile <- file.path(data.path, "BankXDF.xdf") 
BankDS <- RxXdfData(file = infile) 

houseCor <- rxCor(formula=~age + balance + noHousing, data = BankDS, 
                  transforms = list( noHousing = housing == "no"))

## ----corValues, output.max = 15------------------------------------------
houseCor

