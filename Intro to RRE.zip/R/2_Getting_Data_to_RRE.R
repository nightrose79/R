## ----dirsetup------------------------------------------------------------
data.path <- "../data"
output.path  <- "../output/xdf"
if (is.na(file.info(output.path)$isdir)) dir.create(output.path, recursive = TRUE)
(infile <- file.path(data.path, "bank-full.csv"))
(outfile <- file.path(output.path, "BankXDF.xdf"))

## ----rxImportArgs--------------------------------------------------------
args(rxImport)

## ----rxImport------------------------------------------------------------
colClasses <- c("integer", rep("factor",4), "integer", 
                rep("factor",3), "integer", "factor", rep("integer",4), rep("factor",2))
names(colClasses) <- c("age", "job", "marital", "education", "default", "balance", 
"housing", "loan", "contact", "day", "month", "duration", "campaign", 
"pdays", "previous", "poutcome", "y")

BankXDF <- rxImport(inData = infile, outFile = outfile,
                    colClasses=colClasses, rowsPerRead=10000,
                    overwrite = TRUE)

## ----churninfo-----------------------------------------------------------
ChurnXDF <- file.path(data.path, "ChurnData.xdf")
ChurnXDF <-RxXdfData(ChurnXDF)
bankTypes <- vapply(bankVarInfo,"[[","varType",Fun.value=character(1))
lapply(bankVarInfo[bankTypes == "integer"],"[[","high")

## ----rxGetInfoArgs-------------------------------------------------------
args(rxGetInfo)

## ----rxGetInfoBank, output.max = 13--------------------------------------
rxGetInfo(BankXDF, getVarInfo = TRUE)

## ----dataSource----------------------------------------------------------
infile <- file.path(data.path, "bank-full.csv") 
BankDS <- RxTextData(file = infile) 
rxGetInfo(BankDS, numRows=6)

