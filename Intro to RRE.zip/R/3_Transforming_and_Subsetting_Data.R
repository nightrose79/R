library(help=RevoScaleR)

## ----argsrxDataStep------------------------------------------------------
args(rxDataStep)

## ----dirsetup------------------------------------------------------------
## set up general directories
data.path <- "../data"
output.path <- "../output/xdf"
if (is.na(file.info(output.path)$isdir)) dir.create(output.path, recursive = TRUE)
## set up bank paths
infile <- file.path(data.path, "BankXDF.xdf") 
origBankDS <- RxXdfData(file = infile)
outfile <- file.path(output.path, "myBankXDF.xdf") 
## set up churn paths:
inChurnfile <-  file.path(data.path, "ChurnData.xdf")
ChurnDS <-  RxXdfData(inChurnfile)
outChurnfile <-  file.path(output.path, "myChurnData.xdf")
## ----rxDataStepExample---------------------------------------------------
BankDS <- rxDataStep(inData = origBankDS, outFile = outfile, 
                        varsToKeep = c("balance", "age", "y", "poutcome"), overwrite = TRUE)
BankDS

## ----getVarInfoBankDS----------------------------------------------------
rxGetVarInfo(BankDS)

## ----rowSelection--------------------------------------------------------
outfile.rs <- file.path(output.path, "BankRS.xdf")
BankDS.rs <- rxDataStep(inData = origBankDS, outFile = outfile.rs, 
                        rowSelection = age > 21,
                        overwrite = TRUE)
BankDS.rs

## ----rowSelection2-------------------------------------------------------
outfile.rs <- file.path(output.path, "BankRS.xdf")
BankDS.rs <- rxDataStep(inData = origBankDS, outFile = outfile.rs, 
                        varsToKeep = c("balance",  "y", "age","poutcome"),
                        rowSelection = ,
                        overwrite = TRUE)
BankDS.rs
outfile.rs<-file.path(output.path,"ChurnRS.xdf")
ChurnDS.rs <- rxDataStep(inData = ChurnDS, outFile = outfile.rs, 
                         varsToKeep = c("n.family.members",  "n.devices"),
                         rowSelection = n.devices >3,
                         overwrite = TRUE)
## ----exampleTransforms---------------------------------------------------
mylist <- list( newBalance = balance + 8019 + 1, newBalance2=balance+10000, age2=age^2)

rxDataStep(inData = BankDS.rs, outFile = BankDS.rs,
           transforms = list( newBalance = balance + 8019 + 1),
           overwrite=TRUE)
rxGetInfo(BankDS.rs, varsToKeep = c("balance", "newBalance"), getVarInfo = TRUE)

## ----LinePlotBalanceAge--------------------------------------------------
rxLinePlot(balance ~ age, type = "p", data = BankDS)

## ----lineplotnewbalanceage-----------------------------------------------
rxLinePlot(newBalance ~ age, type = "p", data = BankDS)
rxHistogram(~age,data = BankDS)
rxLinePlot(balance~age,type="p",data=BankDS,
           panel = function(x,y,...)
             panel.lmline(x,y,...))
##assignment
rxDataStep(inData = ChurnDS.rs, outFile = ChurnDS.rs,
           transforms = list(n.device.per.person = n.devices/n.family.members),
           overwrite=TRUE)

## ----setVarInfoArgs------------------------------------------------------
args(rxSetVarInfo)

## ----setupRecode, tidy=FALSE---------------------------------------------
newVarInfo <- list(
  y = list(
    newName = "term.deposit", 
    description = "Customer has subscribed to a term deposit"
  ), 
  poutcome = list(
    newName = "campaign.outcome", 
    description = "Outcome of prior marketing campaign"
  )
  ) 

## ----setVarInfo----------------------------------------------------------
rxSetVarInfo(varInfo = newVarInfo, data = BankDS) 
rxGetVarInfo( BankDS ) 

## ----rxSortArgs----------------------------------------------------------
args(rxSort)

## ----rxSortExample-------------------------------------------------------
rxSort(inData = BankDS, outFile = BankDS, 
       sortByVars=c('balance', 'age'),
       decreasing = c(FALSE, TRUE),
       overwrite=TRUE)

## ----rxGetInfoSorted-----------------------------------------------------
rxGetInfo(BankDS, numRows=5)

## ----removeDuplicates----------------------------------------------------
outfile2 <- file.path(output.path, "BankXDF_sort2.xdf") 
BankDS2 <- rxSort(inData = BankDS, outFile = outfile2,
                    sortByVars=c('balance', 'age'), decreasing = c(FALSE, TRUE), 
                    removeDupKeys=TRUE, dupFreqVar="Dup_Count", 
                    overwrite = TRUE)

## ----seeDeDuplicate------------------------------------------------------
rxGetInfo(BankDS, numRows=5)
rxGetInfo(BankDS2, numRows=5)

## ----linModExample, eval = FALSE-----------------------------------------
#  linMod <- rxLinMod(balance~age, data=BankDS2, fweights="Dup_Count")

