## ----expExample----------------------------------------------------------
exp(log(2143))

## ----dirsetup------------------------------------------------------------
## set up the paths and datasource
data.path <- "../data"
output.path <- "../output/xdf"
if (is.na(file.info(output.path)$isdir)) dir.create(output.path, recursive = TRUE)
infile <- file.path(data.path, "BankSubXDF.xdf") 
origBankSubDS <- RxXdfData(file = infile) 
outfile <- file.path(output.path,"myBankSubXDF.xdf")

## ----createLog, output.max = 15------------------------------------------
BankSubDS <- rxDataStep(inData = origBankSubDS, outFile = outfile,
                    transforms = list(logBalance = log(newBalance)), 
                    overwrite = TRUE)
BankSubSummary <- rxSummary(~ logBalance, data = BankSubDS)
BankSubSummary

## ----createLoginline, output.max = 15------------------------------------
BankSubSummary2 <- rxSummary(~ logBalance, 
                             transforms = list(logBalance = log(newBalance)), 
                             data = origBankSubDS)
BankSubSummary2

## ----viewLogBalance------------------------------------------------------
rxHistogram(~logBalance, data = BankSubDS)

## ----viewOrigBalance-----------------------------------------------------
rxHistogram(~balance, data = BankSubDS)

## ----defineChurnDS-------------------------------------------------------
origChurnDS <- RxXdfData(file.path(data.path, "ChurnData.xdf"))

## ----getGlobalMinMax-----------------------------------------------------
myBankInfo <- rxGetVarInfo(BankSubDS)
(minBal <- myBankInfo$balance$low)
(maxBal <- myBankInfo$balance$high)

## ----scale01Func---------------------------------------------------------
simplyScale <- function(dataList) {
  dataList[["scaledBalance"]] <- as.double((dataList[["balance"]] - minBalance) / (maxBalance-minBalance))
	dataList[["moreThanHalf"]] <- dataList[["scaledBalance"]] > 0.5
	dataList[["newConst"]] <- rep(23, length.out=length(dataList[[1]]))
	return(dataList)
}

## ----useTransFunc--------------------------------------------------------
rxDataStep(inData=BankSubDS,
           outFile=BankSubDS,
           transformFunc = simplyScale, 
           transformObjects = list(minBalance=minBal, maxBalance=maxBal),
           overwrite=TRUE)

## ----getNewInfo, output.max = 15-----------------------------------------
rxGetInfo(data=BankSubDS, getVarInfo=TRUE, varsToKeep = c("scaledBalance", "moreThanHalf", "newConst"))

## ----HistNewVar----------------------------------------------------------
rxHistogram(~scaledBalance, data =BankSubDS, xnNumTicks=15)

## ----summarizeNewVar, output.max = 15------------------------------------
rxSummary(~scaledBalance, data=BankSubDS)

## ----badScale------------------------------------------------------------
badScale <- function(dataList) {
  curMin <- min(dataList[["balance"]])
  curMax <- max(dataList[["balance"]])
  dataList[["scaledBalance2"]] <- as.double((dataList[["balance"]] - curMin ) / (curMax - curMin))
	return(dataList)
}

## ----useBadTransFunc-----------------------------------------------------
rxDataStep(inData=BankSubDS,
           outFile=BankSubDS,
           transformFunc = badScale, 
           transformObjects = list(minBalance=minBal, maxBalance=maxBal),
           overwrite=TRUE)

## ----Bal1vsBal2----------------------------------------------------------
rxHistogram( ~ scaledBalanceDiff, 
             transforms = list(scaledBalanceDiff = scaledBalance - scaledBalance2),
             data=BankSubDS)

## ----scaledBalance3------------------------------------------------------
c(minBal,maxBal)
rxDataStep(inData=BankSubDS,
           outFile=BankSubDS,
           transforms = list( scaledBalance3 = (balance - (-8019)) / (102127-(-8019))),
           overwrite=TRUE)

## ----Bal1vsBal3, output.max = 15-----------------------------------------
rxSummary( ~ scaledBalanceDiff, 
             transforms = list(scaledBalanceDiff = scaledBalance - scaledBalance3),
             data=BankSubDS)

## ----scaledBalance4------------------------------------------------------
rxDataStep(inData=BankSubDS,
           outFile=BankSubDS,
           transformObjects = list(myMinBal = minBal, myMaxBal = maxBal),
           transforms = list( scaledBalance4 = (balance - myMinBal) / (myMaxBal - myMinBal)),
           overwrite=TRUE)

## ----Bal1vsBal4, output.max = 15-----------------------------------------
rxSummary( ~ scaledBalanceDiff2, 
             transforms = list(scaledBalanceDiff2 = scaledBalance - scaledBalance4),
             data=BankSubDS)

## ----manualFactorFun-----------------------------------------------------
manualFactorRecoding <- function(dataList) {
  dataList[["F_n.devices"]] <- factor(dataList[["n.devices"]])
	return(dataList)
}

## ----setupChurn----------------------------------------------------------
infile <- file.path(data.path, "ChurnData.xdf") 
origChurnDS <- RxXdfData(file = infile) 
churnoutfile <- file.path(output.path, "myChurnData.xdf")

## ----badfactorusage, eval=FALSE------------------------------------------
#  ChurnDS <- rxDataStep(inData=origChurnDS,
#             outFile = churnoutfile,
#             transformFunc=manualFactorRecoding,
#             overwrite=TRUE)
#  
#  # Rows Read: 500000, Total Rows Processed: 500000, Total Chunk Time: 0.686 seconds
#  # Existing and new value labels must be the same. There are fewer value labels in the new data for variable F_n.devices.
#  # Error in rxCall("RxDataStep", params) :

## ----badfactortry2, eval=FALSE-------------------------------------------
#  ChurnDS <- rxDataStep(inData=origChurnDS,
#             outFile = churnoutfile,
#             transformFunc=manualFactorRecoding,
#             overwrite=TRUE)
#  
#  # Rows Read: 500000, Total Rows Processed: 500000, Total Chunk Time: 0.686 seconds
#  # Existing and new value labels must be the same. There are fewer value labels in the new data for variable F_n.devices.
#  # Error in rxCall("RxDataStep", params) :

## ----fixManualFactors----------------------------------------------------
rxGetVarInfo(origChurnDS, varsToKeep = "n.devices")
manualFactorRecoding <- function(dataList) {
  dataList[["F_n.devices"]] <- factor(dataList[["n.devices"]],levels=seq(1,10))
  return(dataList)
}

ChurnDS <- rxDataStep(inData=origChurnDS, 
           outFile = churnoutfile,
           transformFunc=manualFactorRecoding,  
           overwrite=TRUE)

## ----rxFactorsExample, output.max = 15-----------------------------------
rxFactors(inData=ChurnDS, 
	      outFile=ChurnDS, 
        varsToKeep = rxGetVarNames(origChurnDS),
		  factorInfo=list(F_n.devices2 = list(levels=seq(1:10), varName="n.devices")),
		  overwrite=TRUE)
rxGetInfo(ChurnDS, getVarInfo=TRUE, varsToKeep = c("n.devices", "F_n.devices2", "F_n.devices"))

## ----crossTabsFfun, output.max = 15, eval = FALSE------------------------
#  rxCrossTabs(~F(n.devices):F_n.devices, data=ChurnDS)$counts

## ----crossTabsFfun2, output.max = 15, eval = FALSE-----------------------
#  rxCrossTabs(~F(n.devices):F_n.devices2, data=ChurnDS)$counts

## ----CreateURNs, output.max = 15-----------------------------------------
rxDataStep(inData = BankSubDS,
           outFile = BankSubDS,
           transforms=list(urns = sample(10, .rxNumRows, replace = TRUE)),
           overwrite=TRUE)
rxGetInfo(BankSubDS, getVarInfo=TRUE, varsToKeep = c("urns"), numRows = 6)$data

## ----viewURNs------------------------------------------------------------
rxHistogram(~urns, BankSubDS, xNumTicks=10)

